# Deploying via Microsoft Intune

This guide walks through deploying `forticlient-vpn-deploy` to Windows endpoints managed by Intune.

## Approach

We use an Intune **Platform script** to register a one-shot scheduled task. The task does the actual install at next boot, running as SYSTEM. This pattern avoids long-running Intune script timeouts and works even if the device is offline at policy-apply time.

## Steps

### 1. Stage the installer

On `10.10.8.200`, ensure the following are present:

```
\\10.10.8.200\Software\FortiClient\FortiClientVPN-7.0.9-x64.msi
\\10.10.8.200\Software\FortiClient\FortiClientVPN-7.0.9-x64.msi.sha256   (recommended)
\\10.10.8.200\Software\FortiClient\vpn-profile.xml                       (optional)
```

Share permissions: grant **read** to the computer accounts of target endpoints. For workgroup machines, see Troubleshooting.md.

### 2. Combine the scripts (Intune runs a single file)

Create a wrapper that contains both scripts inline, or upload `Register-ScheduledTask.ps1` as the main script and embed `Install-FortiClient.ps1` as a here-string. Simplest: zip the two scripts, host on the same share, and have the Intune script pull and execute them. Example wrapper:

```powershell
$src = '\\10.10.8.200\Software\FortiClient\scripts'
$dst = 'C:\ProgramData\CompanyName\FortiClientDeploy'
New-Item -ItemType Directory -Path $dst -Force | Out-Null
Copy-Item "$src\Install-FortiClient.ps1"   "$dst\Install-FortiClient.ps1"   -Force
Copy-Item "$src\Register-ScheduledTask.ps1" "$dst\Register-ScheduledTask.ps1" -Force
& "$dst\Register-ScheduledTask.ps1"
```

### 3. Upload to Intune

1. Intune admin center → **Devices** → **Scripts and remediations** → **Platform scripts** → **Add** → **Windows 10 and later**.
2. Name: `FortiClient VPN 7.0.9 - Register Deploy Task`.
3. Upload the wrapper from step 2.
4. Settings:
   - Run this script using the logged-on credentials: **No**
   - Enforce script signature check: **No** (or sign it if your org requires)
   - Run script in 64-bit PowerShell host: **Yes**
5. Assign to your device group.

### 4. Verify

After devices check in and reboot once:

```powershell
Get-ScheduledTask -TaskName 'Deploy-FortiClientVPN'
Test-Path 'C:\ProgramData\CompanyName\FortiClientDeploy\installed-7.0.9.flag'
```

### 5. Reporting

Intune doesn't natively report on the install outcome. Two options:
- **Proactive remediation**: detection script checks for the marker; remediation re-runs `Register-ScheduledTask.ps1`.
- **Custom inventory**: ship the log directory to a central location (Azure Log Analytics, file share) via a follow-up script.
