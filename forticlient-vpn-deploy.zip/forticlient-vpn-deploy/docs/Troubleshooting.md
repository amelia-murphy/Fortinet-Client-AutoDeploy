# Troubleshooting

## Logs to check first

```
C:\ProgramData\CompanyName\FortiClientDeploy\Logs\install-*.log    ← our script
C:\ProgramData\CompanyName\FortiClientDeploy\Logs\msi-*.log        ← msiexec verbose
```

Also check the Task Scheduler history for `Deploy-FortiClientVPN`.

---

## "Installer not found at \\10.10.8.200\..."

The SYSTEM account on the endpoint can't read the share. Common causes:

### Workgroup environment (no domain)
SYSTEM presents anonymously to the file server. Options:
1. **Easiest:** allow anonymous read on that specific share (acceptable for non-sensitive installers, never for the VPN profile).
2. **Better:** pre-stage credentials with `cmdkey` before the task fires:
   ```powershell
   cmdkey /add:10.10.8.200 /user:DEPLOY\fileread /pass:<password>
   ```
   This must be done in the SYSTEM credential store. Use `psexec -s -i cmdkey ...` or run from a SYSTEM-context script.
3. **Best:** front the share with HTTP(S) (IIS, nginx, or even a simple Python server on `10.10.8.200`) and switch `Copy-Item` to `Invoke-WebRequest`. One-line change in `Install-FortiClient.ps1`.

### SMB version mismatch
Newer Windows disables SMBv1. If the server is old:
```powershell
Get-WindowsOptionalFeature -Online -FeatureName SMB1Protocol
```
Upgrade the server rather than re-enable SMBv1 on endpoints.

---

## MSI exit 1603 (fatal install error)

Open the MSI log (`msi-*.log`) and search for `Return value 3`. The line above is usually the actual cause. Common culprits:
- Conflicting Fortinet product already installed — uninstall first via `Uninstall-FortiClient.ps1`.
- Pending reboot from a prior install — reboot, then re-trigger the task.
- Group Policy software restriction blocking msiexec.

---

## MSI exit 1618 (another install in progress)

Windows Installer is busy. The script exits non-zero and the scheduled task will retry on the next boot. You can also retry manually:
```powershell
Start-ScheduledTask -TaskName 'Deploy-FortiClientVPN'
```

---

## Script runs but FortiClient doesn't appear in Add/Remove Programs

Check whether the install succeeded but under a different display name:
```powershell
Get-ItemProperty 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*' |
    Where-Object DisplayName -match 'Forti' |
    Select DisplayName, DisplayVersion, InstallDate
```
FortiClient 7.x sometimes registers under "FortiClient" without the "VPN" suffix.

---

## VPN profile didn't import

`FCConfig.exe` location varies by FortiClient version. Verify:
```powershell
Get-ChildItem 'C:\Program Files\Fortinet' -Recurse -Filter 'FCConfig.exe'
```
Update the path in `Install-FortiClient.ps1` if it differs.

The profile import also requires the FortiClient service to be running. If it's set to delayed-start, the import may race — add a `Start-Sleep -Seconds 30` before the import, or run it from a separate logon-time task.

---

## Force a clean re-deploy on one endpoint

```powershell
.\Uninstall-FortiClient.ps1
Remove-Item 'C:\ProgramData\CompanyName\FortiClientDeploy\installed-*.flag' -Force
Start-ScheduledTask -TaskName 'Deploy-FortiClientVPN'
```
